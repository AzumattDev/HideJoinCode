| `Version` | `Update Notes`                                                                                            |
|-----------|-----------------------------------------------------------------------------------------------------------|
| 1.0.1     | - Fix up for an awesome streamer (tangofrags)<br/> - Fix includes moving to TextMeshPro to prevent errors |
| 1.0.0     | - Initial Release                                                                                         |