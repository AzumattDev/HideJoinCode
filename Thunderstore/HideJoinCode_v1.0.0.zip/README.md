# Description

##  Quick and dirty mod that I made to hide the join code of the server you're connected to inside of the Game Menu when using crossplay. Requested by a videogame streamer.


#### Server

`This mod is not needed on a server. It's client only. Install on each client that you wish to have the mod load.`

As long as the dll ends up in your BepInEx\plugins folder, you're good to go. If you're using a mod manager please make
sure that it's inside the mod profile's version of that folder.

`Feel free to reach out to me on discord if you need manual download assistance.`

# Author Information

### Azumatt

`DISCORD:` Azumatt#2625

`STEAM:` https://steamcommunity.com/id/azumatt/

For Questions or Comments, find me in the Odin Plus Team Discord or in mine:

[![https://i.imgur.com/XXP6HCU.png](https://i.imgur.com/XXP6HCU.png)](https://discord.gg/Pb6bVMnFb2)
<a href="https://discord.gg/pdHgy6Bsng"><img src="https://i.imgur.com/Xlcbmm9.png" href="https://discord.gg/pdHgy6Bsng" width="175" height="175"></a>
***


> # Update Information (Latest listed first)

| `Version Number` | `Update Notes`  |
|------------------|-----------------|
| 1.0.0            | Initial Release |
